# Phishing Email Detection Model

A beginner-friendly machine-learning mini project using Scikit-learn to
classify email text as **Phishing** or **Safe**.

## Features
- Uses a labeled email dataset
- TF-IDF text feature extraction
- Logistic Regression classifier
- Accuracy and classification report
- Confusion matrix
- Saves a trained model with Joblib
- Command-line prediction for new email text

## Requirements
Python 3.9+

Install dependencies:

```bash
pip install -r requirements.txt
```

## Train the model

```bash
python src/train_model.py
```

The trained model is saved under `model/`.

## Test a new email

```bash
python src/predict.py --text "Urgent verify your account by clicking this link"
```

## Project Outcome
The project demonstrates a basic NLP/ML pipeline: dataset preparation,
TF-IDF feature extraction, supervised classification, evaluation, and
prediction.

## Note
This is an educational prototype. Real-world phishing detection should use
larger, carefully validated datasets and additional signals such as URL
reputation, sender authentication, headers, and domain information.
