from pathlib import Path
import argparse
import joblib

ROOT = Path(__file__).resolve().parents[1]
MODEL = ROOT / "model" / "phishing_model.joblib"

parser = argparse.ArgumentParser(description="Classify an email as Safe or Phishing.")
parser.add_argument("--text", required=True, help="Email text to classify.")
args = parser.parse_args()

if not MODEL.exists():
    raise SystemExit("Model not found. Run: python src/train_model.py")

model = joblib.load(MODEL)
prediction = model.predict([args.text])[0]
probability = model.predict_proba([args.text])[0][1]

label = "Phishing" if prediction == 1 else "Safe"
print(f"Prediction: {label}")
print(f"Phishing probability: {probability:.2%}")
